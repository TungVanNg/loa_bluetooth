var searchData=
[
  ['fast_5fforward_81',['fast_forward',['../class_bluetooth_a2_d_p_sink.html#a42e01689353026b1ef9883fd5d32f00c',1,'BluetoothA2DPSink']]]
];
