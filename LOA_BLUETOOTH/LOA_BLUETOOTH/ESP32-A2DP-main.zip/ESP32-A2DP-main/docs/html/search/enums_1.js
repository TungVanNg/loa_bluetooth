var searchData=
[
  ['channelinfo_336',['ChannelInfo',['../group__a2dp.html#gadd07e8b0b75b5153b83a4580f2d5c6c0',1,'SoundData.h']]]
];
