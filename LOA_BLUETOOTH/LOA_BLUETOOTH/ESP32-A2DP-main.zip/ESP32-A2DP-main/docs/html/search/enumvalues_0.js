var searchData=
[
  ['both_344',['Both',['../group__a2dp.html#ggadd07e8b0b75b5153b83a4580f2d5c6c0aedf69634e61e7ec5d006874d299bc0d4',1,'SoundData.h']]]
];
